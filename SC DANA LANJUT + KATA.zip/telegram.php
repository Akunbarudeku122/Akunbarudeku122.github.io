<?php
$id_telegram = "6174816088";
$id_botTele  = "6639638602:AAFHrkvUbYPsbDPkNO-AM62r37ylzMrt3ro";
?>
